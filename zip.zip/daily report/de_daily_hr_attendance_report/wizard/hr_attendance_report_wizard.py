# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class HrAttendanceReportWizard(models.TransientModel):
    _name = 'hr.attendance.report.wizard'
    _description = 'Daily Attendance Report'

    on_date = fields.Datetime(string='Date', required=True)
   
    
    
    
    def check_report(self):
        data = {}
        data['form'] = self.read(['on_date'])[0]
        return self.print_hr_attendance_report_xls(data)
        

    def print_hr_attendance_report_xls(self):
        data = {}
        data['form'] = self.read(['on_date'])[0]
        return self.env.ref('de_daily_hr_attendance_report.hr_attendance_report_xlsx').report_action(self, data=data, config=False)
    
    

#     def print_hr_attendance_report_xls(self):

#         data = {
#             'on_date': self.on_date,
# #             'stop_at': self.stop_at,
# #             'shop_ids': self.shop_ids.ids,
#         }
#         return self.env.ref('de_daily_hr_attendance_report.hr_attendance_report_xlsx').report_action(self, data=data)
