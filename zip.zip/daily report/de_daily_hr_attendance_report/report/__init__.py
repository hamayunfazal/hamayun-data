# -*- coding: utf-8 -*-
from . import hr_attendance_report_xls
