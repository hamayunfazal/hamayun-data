# -*- coding: utf-8 -*-

from . import hr_long_service_award