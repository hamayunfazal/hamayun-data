# -*- coding: utf-8 -*-

from . import hr_employee_email_report
