import json
from odoo import models
from odoo.exceptions import UserError


class EmployeeAttendanceXlS(models.AbstractModel):
    _name = 'report.de_employee_attendance_xlsx_report.employee_report'
    _description = 'Employee Attendance Xlsx report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        data = self.env['ourtime.wizard'].browse(self.env.context.get('active_ids'))
        format1 = workbook.add_format({'font_size': '12', 'align': 'center', 'bold': False})
        sheet = workbook.add_worksheet('Employee Attendance Xlsx report')
        bold = workbook.add_format({'bold': True, 'align': 'center', 'border': True})
        sr_no = 0

        sheet.write('A4:A4', 'Date From', bold)
        sheet.write('B4:B4', data.date_from .strftime('%d-%b-%Y'), format1)
        sheet.write('D4:D4', 'Date To', bold)
        sheet.write('E4:E4', data.date_to.strftime('%d-%b-%Y'), format1)


        sheet.set_column('A:B', 20, )
        sheet.set_column('C:C', 30, )
        sheet.set_column('D:D', 20, )
        sheet.set_column('E:F', 20, )
        sheet.set_column('G:H', 20, )
        sheet.set_column('I:J', 20, )
        sheet.set_column('K:L', 20, )

        sheet.write(5, 0, 'Sr No', bold)
        sheet.write(5, 1, 'Emp.Code', bold)
        sheet.write(5, 2, 'Name:', bold)
        sheet.write(5, 3, 'Father name', bold)
        sheet.write(5, 4, 'Total hours', bold)


        row = 8

        for f in data.department_ids:
            dep_count = 0
            if dep_count == 0:
                sheet.write(row, 2, f.name, bold)
                row += 1
            employee_attendance = self.env['hr.employee'].search([('department_id', '=', f.id)])


            for line in employee_attendance:
                total_hours = 0

                sr_no += 1


                attendance = self.env['hr.attendance'].search([('employee_id', '=', line.id),('check_in','>=',data.date_from),('check_out','<=',data.date_to)])

                for linessssss in attendance:
                    total_hours = round(total_hours + linessssss.worked_hours, 2)
                sheet.write(row, 0, sr_no, format1)
                sheet.write(row, 1, line.barcode, format1)
                sheet.write(row, 2, line.name, format1)
                sheet.write(row, 4, total_hours, format1)
                row += 1

        dep_count += 1
