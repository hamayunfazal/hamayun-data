# -*- coding: utf-8 -*-
# from odoo import http


# class DeEmployeeAttendanceXlsxReport(http.Controller):
#     @http.route('/de_employee__attendance_xlsx_report/de_employee__attendance_xlsx_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/de_employee__attendance_xlsx_report/de_employee__attendance_xlsx_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('de_employee__attendance_xlsx_report.listing', {
#             'root': '/de_employee__attendance_xlsx_report/de_employee__attendance_xlsx_report',
#             'objects': http.request.env['de_employee__attendance_xlsx_report.de_employee__attendance_xlsx_report'].search([]),
#         })

#     @http.route('/de_employee__attendance_xlsx_report/de_employee__attendance_xlsx_report/objects/<model("de_employee__attendance_xlsx_report.de_employee__attendance_xlsx_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('de_employee__attendance_xlsx_report.object', {
#             'object': obj
#         })
