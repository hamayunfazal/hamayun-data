# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class EmployeeAttendance(models.TransientModel):
    _name = "ourtime.wizard"
    _description = "Employee Attendance Xlsx Report wizard"

    date_from = fields.Date(string='Date from', required=True)
    date_to = fields.Date(string='Date to', required=True)
    company_ids = fields.Many2many('res.company', string='Company')
    department_ids = fields.Many2many('hr.department', string='department')

    def check_report(self):
        data = {}
        data['form'] = self.read(['date_from', 'date_to', 'company_ids','department_ids'])[0]
        return self._print_report(data)

    def _print_report(self, data):
        data['form'].update(self.read(['date_from', 'date_to', 'company_ids','department_ids'])[0])
        return self.env.ref('de_employee_attendance_xlsx_report.employee_report').report_action(self, data=data, config=False)