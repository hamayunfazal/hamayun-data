# -*- coding: utf-8 -*-
{
    'name': "Employee Attendance xlsx Report",

    'summary': """
       Employee Attendance xlsx Report
       1) Department wise employee
       2) Sr no wise
       3) Employee name
       4) father name
       5) ourtime working hours
       
       
       
       
       """,

    'description': """
         Employee Attendance xlsx Report
       1) Department wise employee
       2) Sr no wise
       3) Employee name
       4) father name
       5) our time working hours
    """,

    'author': "Dynaxel",
    'website': "http://www.dyanxel.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '14.0.1',

    # any module necessary for this one to work correctly
    'depends': ['report_xlsx','base','hr'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'wizard/hr_attendance_wizard.xml',
        'report/de_attendance_view.xml',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
